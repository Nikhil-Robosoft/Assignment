/**
 * blog-page controller
 */

import { factories } from '@strapi/strapi'

export default factories.createCoreController('api::article-page.article-page');
