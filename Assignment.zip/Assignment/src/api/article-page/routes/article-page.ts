/**
 * blog-page router
 */

import { factories } from '@strapi/strapi';

export default factories.createCoreRouter('api::article-page.article-page');
