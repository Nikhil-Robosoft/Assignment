/**
 * course-page controller
 */

import { factories } from '@strapi/strapi'

export default factories.createCoreController('api::course-page.course-page');
