/**
 * course-page router
 */

import { factories } from '@strapi/strapi';

export default factories.createCoreRouter('api::course-page.course-page');
