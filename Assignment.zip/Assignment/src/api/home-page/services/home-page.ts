/**
 * home-page service
 */

import { factories } from '@strapi/strapi';

export default factories.createCoreService('api::home-page.home-page');
