/**
 * seo-config controller
 */

import { factories } from '@strapi/strapi'

export default factories.createCoreController('api::seo-config.seo-config');
