/**
 * seo-config router
 */

import { factories } from '@strapi/strapi';

export default factories.createCoreRouter('api::seo-config.seo-config');
