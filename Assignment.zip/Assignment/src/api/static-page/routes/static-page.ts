/**
 * static-page router
 */

import { factories } from '@strapi/strapi';

export default factories.createCoreRouter('api::static-page.static-page');
